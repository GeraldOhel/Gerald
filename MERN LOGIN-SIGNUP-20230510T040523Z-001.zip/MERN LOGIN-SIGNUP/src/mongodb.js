const mongoose = require("mongoose");

mongoose.connect("mongodb+srv://louie123:louie123@test.clsmrku.mongodb.net/?retryWrites=true&w=majority")
.then(() => {
    console.log("mongodb connected");
})
.catch(() => {
    console.log("failed to connect mongodb");
}) 

const LogInSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
})

const collection = new mongoose.model("collection1", LogInSchema)

module.exports=collection